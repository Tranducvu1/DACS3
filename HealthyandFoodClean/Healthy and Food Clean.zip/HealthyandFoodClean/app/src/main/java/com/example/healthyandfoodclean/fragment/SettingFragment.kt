package com.example.healthyandfoodclean.fragment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.navigation.findNavController
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.preference.Preference
import com.example.healthyandfoodclean.R

class SettingFragment : AppCompatActivity() { override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    setContentView(R.layout.fragment_setting)
    setupActionBarWithNavController(findNavController(R.id.fragment_main1))

}
    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.fragment_main1)
        return navController.navigateUp() || super.onSupportNavigateUp()
    }


}