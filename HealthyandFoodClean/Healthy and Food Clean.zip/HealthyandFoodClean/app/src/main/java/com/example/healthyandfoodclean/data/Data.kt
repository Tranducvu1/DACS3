package com.example.healthyandfoodclean

class Data (
    //get du lieu
    id: Int,
    val personname: String,
    val password: String,
    val repassword: String,
    val phone: String)


