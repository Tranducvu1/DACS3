package com.example.healthyandfoodclean

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.SimpleAdapter

class  HealthyArticlesActivity : AppCompatActivity() {
    private lateinit var buttonBack: Button
    private val healthy = arrayOf(
        arrayOf("Đi bộ ", "", "", "", "Click More", ""),
        arrayOf("Dịch Covid", "", "", "", "Click More", ""),
        arrayOf("Ngừng hút thuốc", "", "", "", "Click More", ""),
        arrayOf("Sốt", "", "", "", "Click More", ""),
        arrayOf("Dinh dưỡng tốt", "", "", "", "Click More", ""),
        arrayOf("Uống nước", "", "", "", "Click More", "")
    )
    private val images = intArrayOf(
        R.drawable.health1,
        R.drawable.health2,
        R.drawable.health3,
        R.drawable.health4,
        R.drawable.health5,
        R.drawable.healthy6
    )
    private var itemList = ArrayList<HashMap<String, String>>()
    private lateinit var sa: SimpleAdapter
    private lateinit var lst: ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_healthy_articles)
        buttonBack = findViewById(R.id.buttonBack)
        lst = findViewById(R.id.listview)

        buttonBack.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
        }

        for (i in healthy.indices) {
            val item = HashMap<String, String>()
            item["Line1"] = healthy[i][0]
            item["Line2"] = healthy[i][1]
            item["Line3"] = healthy[i][2]
            item["Line4"] = healthy[i][3]
            item["Line5"] = healthy[i][4]
            item["Line6"] = healthy[i][5]
            itemList.add(item)
        }

        sa = SimpleAdapter(
            this,
            itemList,
            android.R.layout.simple_list_item_1,
            arrayOf("Line1", "Line2", "Line3", "Line4", "Line5", "Line6"),
            intArrayOf(
                android.R.id.text1,
                android.R.id.text2,

                )
        )
        lst.adapter = sa
        lst.setOnItemClickListener { adapterView, view, i, l ->
            val it = Intent(this, HealthyArticleDetailActivity::class.java)
            it.putExtra("text1", healthy[i][0])
            it.putExtra("text2", images[i])
            startActivity(it)
        }
    }
}