package com.example.healthyandfoodclean
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.example.healthyandfoodclean.databinding.ActivityHomeBinding
import com.example.healthyandfoodclean.fragment.SettingFragment
import com.google.android.material.navigation.NavigationView


class HomeActivity : AppCompatActivity() {
    private lateinit var drawer: DrawerLayout
    var isDarkMode: Boolean = true
    private lateinit var switch1: Switch
    private lateinit var nav_view: NavigationView
    private lateinit var toggle: ActionBarDrawerToggle
    private lateinit var binding: ActivityHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        drawer = findViewById(R.id.drawlayout)
        nav_view = findViewById(R.id.nav_view)

        toggle = ActionBarDrawerToggle(this, drawer, R.string.open_nav, R.string.close_nav)
        drawer.addDrawerListener(toggle)
        toggle.syncState()
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

//        binding..setOnClickListener {
//            if (isDarkMode)
//            {
//                isDarkMode=false
//                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
//            }
//            else
//            {
//                isDarkMode=true
//                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
//            }
//
//        }

        nav_view.setNavigationItemSelectedListener {

            when (it.itemId) {
                R.id.nav_home ->
                    startActivity(
                        Intent(
                            this,
                            HomeActivity::class.java
                        )
                    )
                R.id.nav_about -> Toast.makeText(
                    applicationContext,
                    "Click About",
                    Toast.LENGTH_SHORT
                ).show()
                R.id.nav_settings ->
                    startActivity(
                        Intent(
                            this,
                            SettingFragment::class.java
                        )
                    )

                R.id.nav_logout ->
                    startActivity(
                        Intent(
                            this,
                            LoginActivity::class.java
                        )
                    )
            }
            true

        }
        binding.healthyarticles.setOnClickListener {
            startActivity(
                Intent(
                    this, HealthyArticlesActivity::class.java

                )
            )
        }

        binding.doexercise.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    ExcerciseActivitty::class.java

                )
            )
        }
        binding.runner.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    BaseApplication::class.java

                )
            )
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.switch1 -> {
                if (item.title == "TODO") {
                    item.icon = ContextCompat.getDrawable(this, R.drawable.baseline_change_circle_24)
                    item.title = "DONE"
// Thực hiện thay đổi màu giao diện từ đen sang trắng ở đây
                } else {
                    item.icon = ContextCompat.getDrawable(this, R.drawable.baseline_change_circle_24)
                    item.title = "TODO"
// Thực hiện thay đổi màu giao diện từ trắng sang đen ở đây
                }
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }
    private fun change(){
        if (isDarkMode)
        {
            isDarkMode=false
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        }
        else
        {
            isDarkMode=true
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        try {
            val inflater = menuInflater
            inflater.inflate(R.menu.swtich,menu)
        }catch (e:java.lang.Exception){
            e.printStackTrace()
        }
        return super.onCreateOptionsMenu(menu)
    }
}
