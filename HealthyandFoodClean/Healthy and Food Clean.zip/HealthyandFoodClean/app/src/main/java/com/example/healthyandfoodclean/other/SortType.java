package com.example.healthyandfoodclean.other;

public enum SortType {
    DATE, RUNNING_TIME, DISTANCE, AVG_SPEED, CALORIES_BURNED
}
