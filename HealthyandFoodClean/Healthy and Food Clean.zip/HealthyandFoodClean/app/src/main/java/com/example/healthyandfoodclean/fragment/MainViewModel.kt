package com.example.healthyandfoodclean.fragment

class MainViewModel {

}
