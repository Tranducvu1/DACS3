package com.example.healthyandfoodclean

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.widget.Toolbar
class ExcerciseActivitty : AppCompatActivity() {
    private lateinit var start:Button
    private lateinit var start2 :Button
    private lateinit var toolbar:Toolbar
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_excercise_activitty)
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        val button1 = findViewById<Button>(R.id.start)
        val button2 = findViewById<Button>(R.id.start2)

        button1.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    SecondActivity::class.java
                )
            )
        }
        button2.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    SecondActivity2::class.java
                )
            )
        }
        }

    fun beforeage18(view: View) {

        startActivity(
            Intent(
                this,
                SecondActivity::class.java
            )
        )
    }
    fun age18(view: View) {
        startActivity(
            Intent(
                this,
                SecondActivity::class.java
            )
        )
    }
}