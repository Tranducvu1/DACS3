package com.example.healthyandfoodclean


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.healthyandfoodclean.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth

class RegisterActivity : AppCompatActivity() {
    private lateinit var name: EditText
    private lateinit var password: EditText
    private lateinit var repassword: EditText
    private lateinit var phonenumber: EditText
    private lateinit var btnregister: Button
    private lateinit var binding: ActivityRegisterBinding
    private lateinit var firebaseAuth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        passwordFocusListener()
        firebaseAuth = FirebaseAuth.getInstance()
        btnregister = binding.btnregister
        btnregister.setOnClickListener {
            val username = name.text.toString()
            val password = password.text.toString()
            val repassword = repassword.text.toString()
            val phonenumber = phonenumber.text.toString()
            val db = MyDatabaseHelper(applicationContext, "HAF", null, 1)
            if (username.isEmpty() || password.isEmpty()|| repassword.isEmpty()|| phonenumber.isEmpty()) {

                Toast.makeText(this, "Please fill all details", Toast.LENGTH_SHORT).show()
            } else
                if (password.compareTo(repassword)==0)
                {
                    db.register(username,password,repassword,phonenumber)
                    submitForm()
                    Toast.makeText(this, "Record inserted", Toast.LENGTH_SHORT).show()
                    startActivity(
                        Intent(
                            this,
                            LoginActivity::class.java
                        )
                    )
                }
                else {
                    Toast.makeText(this, "Please insert again", Toast.LENGTH_SHORT).show()
                }
        }
    }
    private fun passwordFocusListener()
    {
        binding.password.setOnFocusChangeListener { _, focused ->
            if(!focused)
            {
                binding.passwordContainer.helperText = validrePassword()
                binding.repasswordContainer.helperText = validrePassword()
            }
        }
    }
    private fun validPassword(): String?
    {
        val passwordText = binding.password.text.toString()
        if(passwordText.length < 8)
        {
            return "Minimum 8 Character Password"
        }
        if(!passwordText.matches(".*[A-Z].*".toRegex()))
        {
            return "Must Contain 1 Upper-case Character"
        }
        if(!passwordText.matches(".*[a-z].*".toRegex()))
        {
            return "Must Contain 1 Lower-case Character"
        }
        if(!passwordText.matches(".*[@#\$%^&+=].*".toRegex()))
        {
            return "Must Contain 1 Special Character (@#\$%^&+=)"
        }

        return null
    }
    private fun resetForm()
    {
        var message = "personame: " +  binding.personname.text
        message += "\nPassword: " + binding.password.text
        message += "\nrepassword: " + binding.repassword.text
        message += "\nPhonenumber: " + binding.phone.text


        AlertDialog.Builder(this)
            .setTitle("Form submitted")
            .setMessage(message)
            .setPositiveButton("Okay"){ _,_ ->

                binding.password.text = null
                binding.personname.text = null
                binding.repassword.text = null
                binding.phone.text = null

                binding.personContainer.helperText = getString(R.string.required)
                binding.passwordContainer.helperText = getString(R.string.required)
                binding.repasswordContainer.helperText = getString(R.string.required)
                binding.phoneContainer.helperText = getString(R.string.required)

            }
            .show()
    }
    private fun validrePassword(): String?
    {
        val repasswordText = binding.repassword.text.toString()
        if(repasswordText.length < 8)
        {
            return "Minimum 8 Character Password"
        }
        if(!repasswordText.matches(".*[A-Z].*".toRegex()))
        {
            return "Must Contain 1 Upper-case Character"
        }
        if(!repasswordText.matches(".*[a-z].*".toRegex()))
        {
            return "Must Contain 1 Lower-case Character"
        }
        if(!repasswordText.matches(".*[@#\$%^&+=].*".toRegex()))
        {
            return "Must Contain 1 Special Character (@#\$%^&+=)"
        }

        return null
    }
    private fun phoneFocusListener()
    {
        binding.phone.setOnFocusChangeListener { _, focused ->
            if(!focused)
            {
                binding.phoneContainer.helperText = validPhone()
            }
        }
    }
    private fun invalidForm()
    {
        var message = ""
        if(binding.personContainer.helperText != null)
            message += "\n\nEmail: " + binding.personContainer.helperText
        if(binding.passwordContainer.helperText != null)
            message += "\n\nPassword: " + binding.passwordContainer.helperText
        if(binding.repasswordContainer.helperText != null)
            message += "\n\nrepassword: " + binding.repasswordContainer.helperText
        if(binding.phoneContainer.helperText != null)
            message += "\n\nPhone: " + binding.phoneContainer.helperText
        AlertDialog.Builder(this)
            .setTitle("Invalid Form")
            .setMessage(message)
            .setPositiveButton("Okay"){ _,_ ->
                // do nothing
            }
            .show()
    }
    private fun submitForm()
    {
        binding.repasswordContainer.helperText = validPassword()
        binding.passwordContainer.helperText = validPassword()
        binding.phoneContainer.helperText = validPhone()

        val validrePassword = binding.repasswordContainer.helperText == null
        val validPassword = binding.passwordContainer.helperText == null
        val validPhone = binding.phoneContainer.helperText == null

        if ( validrePassword && validPassword && validPhone)
            resetForm()
        else
            invalidForm()
    }
    private fun validPhone(): String?
    {
        val phoneText = binding.phone.text.toString()
        if(!phoneText.matches(".*[0-9].*".toRegex()))
        {
            return "Must be all Digits"
        }
        if(phoneText.length != 10)
        {
            return "Must be 10 Digits"
        }
        return null
    }
}
