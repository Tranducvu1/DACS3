package com.example.healthyandfoodclean.data

import androidx.room.Dao
import androidx.room.Query


@Dao
interface RecipeDao {
   @Query("SELECT * FROM ")
}